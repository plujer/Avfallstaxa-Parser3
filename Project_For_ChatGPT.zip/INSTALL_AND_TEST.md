# Excel Builder – Project Package Tool v1.0

Detta paket ersätter den tidigare PowerShell-baserade `create_project_package.bat`.

## Filer

Lägg filerna i projektets rotmapp:

```text
tools/create_project_package.py
create_project_package.bat
```

## Körning

Dubbelklicka eller kör:

```bat
create_project_package.bat
```

Den skapar:

```text
Project_For_ChatGPT.zip
```

## Exkluderas automatiskt

- `.git`
- `.venv` / `venv`
- `__pycache__`
- `.pytest_cache`
- `output`
- `rapportzip`
- `dist`
- `build`
- `.mypy_cache`
- `.ruff_cache`
- `.idea`
- `.vscode`
- `.pyc`, `.pyo`, `.log`, `.tmp`

## Skicka tillbaka

Skicka endast:

```text
Project_For_ChatGPT.zip
```
